import React, { useState, useRef, useEffect } from 'react';
import './App.css'; // Import your CSS file
import axios from 'axios';
import ReactMarkdown from 'react-markdown';
import Loader from './Loader'; // Import your loading component
import img1 from './assets/zenith-ai.png'; // Import your image file
import ClipboardJS from 'clipboard'; // Import the clipboard library

const predefinedResponses = {
  "who are you": "I'm Zenith AI, an NLP model trained to assist you with information and conversation. Trained on a massive dataset including Google Gemini, Claude, and Github Copilot.",
  "what is your name": "I'm Zenith AI!",
  "who is your developer": "I'm Zenith AI, an NLP model trained to assist you with information and conversation. Trained on a massive dataset including Google Gemini, Claude, and Github Copilot. And i was developed by a team of developers at Grww.Tech .",
 "what is your purpose": "I'm Zenith AI, an NLP model trained to assist you with information and conversation. Trained on a massive dataset including Google Gemini, Claude, and Github Copilot.",

};

function App() {
  const [question, setQuestion] = useState(""); // State for user question
  const [answer, setAnswer] = useState(""); // State for generated answer
  const [generatingAnswer, setGeneratingAnswer] = useState(false); // State for generating indicator
  const copyRef = useRef(null); // Ref to reference the answer text element
  const [isCopied, setIsCopied] = useState(false); // State for copy button text

  // Fetch initial answer (optional)
  useEffect(() => {
    const fetchInitialAnswer = async () => {
      setAnswer("Welcome to Zenith AI! Ask me anything.");
    };
    fetchInitialAnswer();
  }, []);

  async function generateAnswer(e) {
    setGeneratingAnswer(true);
    e.preventDefault();

    const lowerCaseQuestion = question.toLowerCase(); // Convert question to lowercase for case-insensitive matching

    if (predefinedResponses.hasOwnProperty(lowerCaseQuestion)) {
      setAnswer(predefinedResponses[lowerCaseQuestion]);
    } else {
      // Call your existing logic to fetch answer from API
      try {
        const response = await axios({
          url: "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=AIzaSyCzAbfjvH7cj58bo6RTFHppAiiuwZ2SCII", // Replace with your Google AI API key
          method: "post",
          data: {
            contents: [{ parts: [{ text: question }] }],
          },
        });

        setAnswer(
          response["data"]["candidates"][0]["content"]["parts"][0]["text"]
        );
      } catch (error) {
        console.log(error);
        setAnswer("Sorry - Something went wrong. Please try again!");
      }
    }

    setGeneratingAnswer(false);
  }

  const handleCopy = async () => {
    console.log('Text to copy:', answer); // Log the text to be copied
  
    setIsCopied(true); // Set state to "Copied" before copy operation
  
    try {
      await navigator.clipboard.writeText(answer);
      console.log('Copy successful'); // Log a success message
    } catch (error) {
      console.error('Failed to copy text using navigator.clipboard:', error);
    }
  }

  const handleRetry = () => {
    setQuestion(""); // Clear the question field
    generateAnswer(); // Re-generate the answer
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Zenith AI</h1>
        <img src={img1} alt="Zenith AI Robot" className="zenith-logo" />
      </header>
      
        <nav className="chat-navigation">
          <button className="nav-button">Home</button>
          <button className="nav-button">Documentation</button>
          <button className="nav-button">Settings</button>
        </nav>
        <main className="chat-container">
        <section className="chat-content">
          
          <div className="ai-message">
            <ReactMarkdown className="answer-text" ref={copyRef}>{answer}</ReactMarkdown>
          </div>
          <form onSubmit={generateAnswer} className="question-form">
            <textarea
              required
              className="question-input"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask Zenith AI"
            />
            <div className="button-container">
              <button type="submit" className="search-button" disabled={generatingAnswer}>
                {generatingAnswer ? <Loader /> : "Ask Zenith AI"}
              </button>
              <button className={`copy-button ${isCopied ? 'copied' : ''}`} onClick={handleCopy} disabled={!answer}>
                {isCopied ? 'Copied!' : 'Copy'}
              </button>
              <button className="retry-button" onClick={handleRetry} disabled={!answer}>
                Retry
              </button>
            </div>
          </form>
        </section>
      </main>
    </div>
  );
}

export default App;
